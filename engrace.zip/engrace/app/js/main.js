// Swiper init
new Swiper(".slider", {
  slidesPerView: 3,
  watchOverflow: true,
  autoHeight: true,
  spaceBetween: 18,

  navigation: {
    nextEl: ".swiper-nav .swiper-button__right",
    prevEl: ".swiper-nav .swiper-button__left",
  },

  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});
